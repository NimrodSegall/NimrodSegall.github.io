Here is [a two pages template, perfect for awsome projects](http://silex-templates.silex.me/clean-square/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on github.

[![screenshot-800x600](http://silex-templates.silex.me/clean-square/screenshot-678x336.png)](http://silex-templates.silex.me/clean-square/)

