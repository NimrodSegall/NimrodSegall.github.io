Here is a [3 pages online resume template, for you to advertise your skills and centralize the links about your professional life](http://silex-templates.silex.me/perso2/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on [github pages](https://pages.github.com/).

[![screenshot](http://silex-templates.silex.me/perso2/screenshot-678x336.png)](http://silex-templates.silex.me/perso2/)
