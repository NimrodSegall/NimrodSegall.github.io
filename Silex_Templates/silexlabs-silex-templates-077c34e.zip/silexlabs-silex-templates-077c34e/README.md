silex-templates
===============

A repository for [Silex templates, see the website and the templates here](http://templates.silex.me/)

