The free [online service template](http://templates.silex.me/templates/online-service/) is ideal for pure players companies.

Use [Silex.me](http://www.silex.me) to edit this template and make it your own.

[![screenshot-678x336](https://cloud.githubusercontent.com/assets/715377/3449666/d8aa5932-0169-11e4-8cf1-6e67f700adcb.png)](http://templates.silex.me/templates/online-service/)

