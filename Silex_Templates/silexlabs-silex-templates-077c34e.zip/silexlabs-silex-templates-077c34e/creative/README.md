Here is [a two pages + products pages, perfect to showcase your creative projects](http://silex-templates.silex.me/creative/). It is made with [Silex free website builder](http://www.silex.me/), and it is hosted for free on github. This work is free and creative commons. The pictures come from unslplash.com community. You can reuse everything for anything.

[![screenshot of free template](http://silex-templates.silex.me/creative/screenshot.png)](http://silex-templates.silex.me/creative/)

