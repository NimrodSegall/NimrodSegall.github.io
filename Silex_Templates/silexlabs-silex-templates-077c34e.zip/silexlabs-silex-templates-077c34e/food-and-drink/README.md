Here is [a 4 pages template, for your restaurant or café](http://silex-templates.silex.me/food-and-drink/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on [github pages](https://pages.github.com/).

[![screenshot](http://silex-templates.silex.me/food-and-drink/screenshot-678x336.png)](http://silex-templates.silex.me/food-and-drink/)

As you can see, this template uses a lot of CSS in order to add transitions, and advanced text styles.
