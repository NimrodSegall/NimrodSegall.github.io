Here is [a 2 pages template, perfect for people selling products for the body](http://silex-templates.silex.me/beauty/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on github.

[![screenshot-800x600](./screenshot.png)](http://silex-templates.silex.me/beauty/)
